
import * as THREE from 'https://cdn.skypack.dev/three@0.129.0/build/three.module.js';

import { OrbitControls } from 'https://cdn.skypack.dev/three@0.129.0/examples/jsm/controls/OrbitControls.js';

import { GLTFLoader }  from 'https://cdn.skypack.dev/three@0.129.0/examples/jsm/loaders/GLTFLoader.js';

const scene = new THREE.Scene()
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);

let object;
let controls
let objToRender = 'can'



// Instantiate a new renderer and set its size
const renderer = new THREE.WebGLRenderer({ alpha: true });  //Alpha: true allows for the transparent background
renderer.setSize(window.innerWidth, window.innerHeight);

// Add the renderer to the DOM
document.getElementById("container3D").appendChild(renderer.domElement);

// Set how far the camera will be from the 3D model
camera.position.z = objToRender === "can" ? 25 : 500;

// Add lights to the scene, so we can actually see the 3D model
const topLight = new THREE.DirectionalLight(0xffffff, 1);  // (color, intensity)
topLight.position.set(500, 500, 500);  // top-left-ish
topLight.castShadow = true;
scene.add(topLight);

const ambientLight = new THREE.AmbientLight(0x333333, objToRender === "can" ? 5 : 1);
scene.add(ambientLight);

const loader = new GLTFLoader();

// 2. Load your .glb model
loader.load(
  `models/${objToRender}.glb`,   // make sure scene.glb exists in that folder
  gltf => {
    object = gltf.scene;
    object.scale.set(100, 100, 100);
    scene.add(object);
    console.log('Model loaded');
  },
  xhr => {
    console.log(`${(xhr.loaded/xhr.total*100).toFixed(1)}% loaded`);
  },
  err => {
    console.error('Load error:', err);
  }
);



// Render the scene
function animate() {
  requestAnimationFrame(animate);

  console.log('animate()', 'object =', object);

  if (object) {
    object.rotation.y += 0.01;
  }

  renderer.render(scene, camera);
}

  
  // Add a listener to the window, so we can resize the window and the camera
  window.addEventListener("resize", function () {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });
  
  // Start the 3D rendering
animate();